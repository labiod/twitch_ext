

if(window.Twitch.ext) {
    console.log("Start extension");
}